package com.dranyas.trangel.registry;

import net.minecraftforge.eventbus.api.IEventBus;

public class TensuraAngelRegistry {
    public static void register(IEventBus modEventBus) {

    }
}